const express = require('express');
const router = express.Router();
var mongoose = require('mongoose');
const excel = require("exceljs");
const Employee = require('../model/employee');
var queryString = "mongodb://127.0.0.1:27017/local";
const db = mongoose.connection;
db.once('open',_=>{
	console.log("db is connected");
})
db.on('error',err =>{
	console.log("error:");
})
mongoose.connect(queryString, { useNewUrlParser: true });
router.get('/getData',async(req,res)=>{
  try{
    let data = await Employee.find();
    let workbook = new excel.Workbook();
    let worksheet = await workbook.addWorksheet("Tutorials");
    worksheet.columns = [
        {header:"Employee Id",key:"employeeId",width:5},
        {header:"Name",key:"name",width:30},
        {header:"Designation",key:"designation",width:20}
    ];
    // res.setHeader(
    const path = "./files";
    worksheet.addRows(data);
    // res.setHeader(
    //     "Content-Type",
    //     "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    //   );
    //   res.setHeader(
    //     "Content-Disposition",
    //     "attachment; filename=" + "tutorials.xlsx"
    //   );
    const data1 = await workbook.xlsx.writeFile(`employees.xlsx`)
   .then(() => {
     res.send({
       status: "success",
       message: "file successfully downloaded",
       path: `/employees.xlsx`,
      });
   });
  }catch(err){
    res.send({
      status:"error",
      message:"Something went wrong"
    });
  }
    //   workbook.xlsx.write(res).then(()=>{
    //     res.status(200).end();
    //   })
   // console.log(data);
   // res.send(data);
});

module.exports = router;