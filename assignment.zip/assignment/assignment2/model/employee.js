const mongoose = require('mongoose');
mongoose.set('debug', true);
const Schema = mongoose.Schema;
const employeeSchema = new Schema({
    employeeId:Number,
    name:String,
    designation:String
},{strict:false});
module.exports = mongoose.model('employee', employeeSchema,'employee');